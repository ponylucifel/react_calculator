import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import './Calc.css';
import Calc from './Calc';

ReactDOM.render(
    <Calc />,
    document.getElementById('root')
);

